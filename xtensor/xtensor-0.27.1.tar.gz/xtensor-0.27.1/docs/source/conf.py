#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess

on_rtd = os.environ.get('READTHEDOCS', None) == 'True'

if on_rtd:
    subprocess.call('cd ..; doxygen', shell=True)

import sphinx_rtd_theme

html_theme = "sphinx_rtd_theme"

html_theme_path = [sphinx_rtd_theme.get_html_theme_path()]

def setup(app):
    app.add_css_file("main_stylesheet.css")

extensions = ['breathe', 'sphinx_rtd_theme']
breathe_projects = { 'xtensor': '../xml' }
breathe_default_project = "xtensor"
templates_path = ['_templates']
html_static_path = ['_static']
source_suffix = '.rst'
master_doc = 'index'
project = 'xtensor'
copyright = '2016, Johan Mabille, Sylvain Corlay and Wolf Vollprecht'
author = 'Johan Mabille, Sylvain Corlay and Wolf Vollprecht'

html_logo = 'quantstack-white.svg'

exclude_patterns = []
highlight_language = 'c++'
pygments_style = 'sphinx'
todo_include_todos = False
htmlhelp_basename = 'xtensordoc'

html_js_files = [
    'goatcounter.js'
]

# Automatically link to NumPy doc
extensions += ['sphinx.ext.intersphinx']
intersphinx_mapping = {
    "numpy": ("https://numpy.org/doc/stable/", None),
    "scipy": ("https://docs.scipy.org/doc/scipy/reference", None),
    "xtensor-blas": ("https://xtensor-blas.readthedocs.io/en/stable", None),
    "xtl": ("https://xtl.readthedocs.io/en/stable", None),
}
