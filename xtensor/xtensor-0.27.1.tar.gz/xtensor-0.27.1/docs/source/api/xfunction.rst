.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay and Wolf Vollprecht

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

xfunction
=========

Defined in ``xtensor/core/xfunction.hpp``

.. doxygenclass:: xt::xfunction
   :members:

Defined in ``xtensor/core/xmath.hpp``

.. doxygenfunction:: make_lambda_xfunction
