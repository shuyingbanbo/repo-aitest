.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay and Wolf Vollprecht

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

xbroadcast
==========

Defined in ``xtensor/views/xbroadcast.hpp``

.. doxygenclass:: xt::xbroadcast
   :members:

.. doxygenfunction:: xt::broadcast(E&&, const S&)
