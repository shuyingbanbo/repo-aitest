const completion: Fig.Spec = {
  name: "zoxide",
  description: "A smarter cd command for your terminal",
  subcommands: [
    {
      name: "add",
      description: "Add a new directory or increment its rank",
      options: [
        {
          name: ["-s", "--score"],
          description: "The rank to increment the entry if it exists or initialize it with if it doesn't",
          isRepeatable: true,
          args: {
            name: "score",
            isOptional: true,
          },
        },
        {
          name: ["-h", "--help"],
          description: "Print help",
        },
        {
          name: ["-V", "--version"],
          description: "Print version",
        },
      ],
      args: {
        name: "paths",
        isVariadic: true,
        template: "folders",
      },
    },
    {
      name: "edit",
      description: "Edit the database",
      subcommands: [
        {
          name: "decrement",
          hidden: true,
          options: [
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
          args: {
            name: "path",
          },
        },
        {
          name: "delete",
          hidden: true,
          options: [
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
          args: {
            name: "path",
          },
        },
        {
          name: "increment",
          hidden: true,
          options: [
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
          args: {
            name: "path",
          },
        },
        {
          name: "reload",
          hidden: true,
          options: [
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
      ],
      options: [
        {
          name: ["-h", "--help"],
          description: "Print help",
        },
        {
          name: ["-V", "--version"],
          description: "Print version",
        },
      ],
    },
    {
      name: "import",
      description: "Import entries from another application",
      subcommands: [
        {
          name: "atuin",
          description: "Import from atuin",
          options: [
            {
              name: "--merge",
              description: "Merge into existing database",
            },
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
        {
          name: "autojump",
          description: "Import from autojump",
          options: [
            {
              name: "--merge",
              description: "Merge into existing database",
            },
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
        {
          name: "fasd",
          description: "Import from fasd",
          options: [
            {
              name: "--merge",
              description: "Merge into existing database",
            },
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
        {
          name: "z",
          description: "Import from z",
          options: [
            {
              name: "--merge",
              description: "Merge into existing database",
            },
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
        {
          name: "z.lua",
          description: "Import from z.lua",
          options: [
            {
              name: "--merge",
              description: "Merge into existing database",
            },
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
        {
          name: "zsh-z",
          description: "Import from zsh-z",
          options: [
            {
              name: "--merge",
              description: "Merge into existing database",
            },
            {
              name: ["-h", "--help"],
              description: "Print help",
            },
            {
              name: ["-V", "--version"],
              description: "Print version",
            },
          ],
        },
      ],
      options: [
        {
          name: "--merge",
          description: "Merge into existing database",
        },
        {
          name: ["-h", "--help"],
          description: "Print help",
        },
        {
          name: ["-V", "--version"],
          description: "Print version",
        },
      ],
    },
    {
      name: "init",
      description: "Generate shell configuration",
      options: [
        {
          name: "--cmd",
          description: "Changes the prefix of the `z` and `zi` commands",
          isRepeatable: true,
          args: {
            name: "cmd",
            isOptional: true,
          },
        },
        {
          name: "--hook",
          description: "Changes how often zoxide increments a directory's score",
          isRepeatable: true,
          args: {
            name: "hook",
            isOptional: true,
            suggestions: [
              "none",
              "prompt",
              "pwd",
            ],
          },
        },
        {
          name: "--no-cmd",
          description: "Prevents zoxide from defining the `z` and `zi` commands",
        },
        {
          name: ["-h", "--help"],
          description: "Print help",
        },
        {
          name: ["-V", "--version"],
          description: "Print version",
        },
      ],
      args: {
        name: "shell",
        suggestions: [
          "bash",
          "elvish",
          "fish",
          "nushell",
          "posix",
          "powershell",
          "tcsh",
          "xonsh",
          "zsh",
        ],
      },
    },
    {
      name: "query",
      description: "Search for a directory in the database",
      options: [
        {
          name: "--exclude",
          description: "Exclude the current directory",
          isRepeatable: true,
          args: {
            name: "exclude",
            isOptional: true,
            template: "folders",
          },
        },
        {
          name: "--base-dir",
          description: "Only search within this directory",
          isRepeatable: true,
          args: {
            name: "base_dir",
            isOptional: true,
            template: "folders",
          },
        },
        {
          name: ["-a", "--all"],
          description: "Show unavailable directories",
        },
        {
          name: ["-i", "--interactive"],
          description: "Use interactive selection",
          exclusiveOn: [
            "-l",
            "--list",
          ],
        },
        {
          name: ["-l", "--list"],
          description: "List all matching directories",
          exclusiveOn: [
            "-i",
            "--interactive",
          ],
        },
        {
          name: ["-s", "--score"],
          description: "Print score with results",
        },
        {
          name: ["-h", "--help"],
          description: "Print help",
        },
        {
          name: ["-V", "--version"],
          description: "Print version",
        },
      ],
      args: {
        name: "keywords",
        isVariadic: true,
        isOptional: true,
      },
    },
    {
      name: "remove",
      description: "Remove a directory from the database",
      options: [
        {
          name: ["-h", "--help"],
          description: "Print help",
        },
        {
          name: ["-V", "--version"],
          description: "Print version",
        },
      ],
      args: {
        name: "paths",
        isVariadic: true,
        isOptional: true,
        template: "folders",
      },
    },
  ],
  options: [
    {
      name: ["-h", "--help"],
      description: "Print help",
    },
    {
      name: ["-V", "--version"],
      description: "Print version",
    },
  ],
};

export default completion;
