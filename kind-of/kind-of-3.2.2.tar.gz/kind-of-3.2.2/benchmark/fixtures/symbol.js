module.exports = [Symbol('foo')];
