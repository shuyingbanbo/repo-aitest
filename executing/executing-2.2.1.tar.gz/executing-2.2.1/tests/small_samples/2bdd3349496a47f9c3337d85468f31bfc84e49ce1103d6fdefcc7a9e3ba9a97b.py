class FunctionProfile:
    ncalls: str