tuple[*a]
