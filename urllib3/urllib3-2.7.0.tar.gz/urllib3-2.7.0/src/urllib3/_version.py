# Auto-generated static version for RPM build
__version__ = "2.7.0"
