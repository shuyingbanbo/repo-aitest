from collections.abc import Callable, Coroutine, Generator, Mapping
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    TypeVar,
    Union,
    cast,
    overload,
)

from pydantic import BaseModel
from pymongo import ReplaceOne
from pymongo.asynchronous.client_session import AsyncClientSession
from pymongo.results import UpdateResult

from beanie.exceptions import DocumentNotFound
from beanie.odm.bulk import BulkWriter
from beanie.odm.cache import LRUCache
from beanie.odm.enums import SortDirection
from beanie.odm.interfaces.aggregation_methods import AggregateMethods
from beanie.odm.interfaces.clone import CloneInterface
from beanie.odm.interfaces.session import SessionMethods
from beanie.odm.interfaces.update import UpdateMethods
from beanie.odm.operators.find.logical import And
from beanie.odm.queries.aggregation import AggregationQuery
from beanie.odm.queries.cursor import BaseCursorQuery
from beanie.odm.queries.delete import (
    DeleteMany,
    DeleteOne,
)
from beanie.odm.queries.update import (
    UpdateMany,
    UpdateOne,
    UpdateQuery,
    UpdateResponse,
)
from beanie.odm.utils.dump import get_dict
from beanie.odm.utils.encoder import Encoder
from beanie.odm.utils.find import construct_lookup_queries, split_text_query
from beanie.odm.utils.parsing import parse_obj
from beanie.odm.utils.projection import get_projection
from beanie.odm.utils.relations import resolve_query_paths

if TYPE_CHECKING:
    from pymongo.asynchronous.command_cursor import AsyncCommandCursor
    from pymongo.asynchronous.cursor import AsyncCursor

    from beanie.odm.documents import DocType

FindQueryProjectionType = TypeVar("FindQueryProjectionType", bound=BaseModel)
FindQueryResultType = TypeVar("FindQueryResultType", bound=BaseModel)


class FindQuery(
    Generic[FindQueryResultType], UpdateMethods, SessionMethods, CloneInterface
):
    """
    Find Query base class
    """

    UpdateQueryType: type[UpdateQuery] | type[UpdateMany] | type[UpdateOne] = (
        UpdateQuery
    )
    DeleteQueryType: type[DeleteOne] | type[DeleteMany] = DeleteMany
    AggregationQueryType = AggregationQuery

    def __init__(self, document_model: type["DocType"]):
        self.document_model = document_model
        self.find_expressions: list[Mapping[str, Any]] = []
        self.projection_model: type[FindQueryResultType] = cast(
            type[FindQueryResultType], self.document_model
        )
        self.session = None
        self.encoders: dict[Any, Callable[[Any], Any]] = {}
        self.ignore_cache: bool = False
        self.encoders = self.document_model.get_bson_encoders()
        self.fetch_links: bool = False
        self.pymongo_kwargs: dict[str, Any] = {}
        self.lazy_parse = False
        self.nesting_depth: int | None = None
        self.nesting_depths_per_field: dict[str, int] | None = None

    def prepare_find_expressions(self):
        if self.document_model.get_link_fields() is not None:
            for i, query in enumerate(self.find_expressions):
                self.find_expressions[i] = resolve_query_paths(
                    query,
                    doc=self.document_model,  # type: ignore
                    fetch_links=self.fetch_links,
                )

    def get_filter_query(self) -> dict[str, Any]:
        """

        Returns: MongoDB filter query

        """
        self.prepare_find_expressions()
        if self.find_expressions:
            return Encoder(custom_encoders=self.encoders).encode(
                And(*self.find_expressions).query
            )
        else:
            return {}

    def delete(
        self,
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        **pymongo_kwargs: Any,
    ) -> DeleteOne | DeleteMany:
        """
        Provide search criteria to the Delete query

        :param session: Optional[AsyncClientSession] - pymongo session
        :return: Union[DeleteOne, DeleteMany]
        """
        self.set_session(session=session)
        return self.DeleteQueryType(
            document_model=self.document_model,
            find_query=self.get_filter_query(),
            bulk_writer=bulk_writer,
            **pymongo_kwargs,
        ).set_session(session=session)

    def project(self, projection_model):
        """
        Apply projection parameter
        :param projection_model: Optional[type[BaseModel]] - projection model
        :return: self
        """
        if projection_model is not None:
            self.projection_model = projection_model
        return self

    def get_projection_model(self) -> type[FindQueryResultType]:
        return self.projection_model

    async def count(self) -> int:
        """
        Number of found documents
        :return: int
        """
        kwargs = {}
        if isinstance(self, FindMany):
            if self.limit_number:
                kwargs["limit"] = self.limit_number
            if self.skip_number:
                kwargs["skip"] = self.skip_number
        kwargs.update(self.pymongo_kwargs)
        return (
            await self.document_model.get_pymongo_collection().count_documents(
                self.get_filter_query(), session=self.session, **kwargs
            )
        )

    async def exists(self) -> bool:
        """
        If find query will return anything

        :return: bool
        """
        cursor = self.document_model.get_pymongo_collection().find(
            filter=self.get_filter_query(),
            projection={"_id": 1},
            limit=1,
            session=self.session,
            **self.pymongo_kwargs,
        )
        return await anext(cursor, None) is not None


class FindMany(
    FindQuery[FindQueryResultType],
    BaseCursorQuery[FindQueryResultType],
    AggregateMethods,
):
    """
    Find Many query class
    """

    UpdateQueryType = UpdateMany
    DeleteQueryType = DeleteMany

    def __init__(self, document_model: type["DocType"]):
        super().__init__(document_model=document_model)
        self.sort_expressions: list[tuple[str, SortDirection]] = []
        self.skip_number: int = 0
        self.limit_number: int = 0

    @overload
    def find_many(
        self: "FindMany[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: None = None,
        skip: int | None = None,
        limit: int | None = None,
        sort: None | str | list[tuple[str, SortDirection]] = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        lazy_parse: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> "FindMany[FindQueryResultType]": ...

    @overload
    def find_many(
        self: "FindMany[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: type[FindQueryProjectionType] | None = None,
        skip: int | None = None,
        limit: int | None = None,
        sort: None | str | list[tuple[str, SortDirection]] = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        lazy_parse: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> "FindMany[FindQueryProjectionType]": ...

    def find_many(
        self: "FindMany[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: type[FindQueryProjectionType] | None = None,
        skip: int | None = None,
        limit: int | None = None,
        sort: None | str | list[tuple[str, SortDirection]] = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        lazy_parse: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> Union[
        "FindMany[FindQueryResultType]", "FindMany[FindQueryProjectionType]"
    ]:
        """
        Find many documents by criteria

        :param args: *Mapping[Any, Any] - search criteria
        :param skip: Optional[int] - The number of documents to omit.
        :param limit: Optional[int] - The maximum number of results to return.
        :param sort: Union[None, str, list[tuple[str, SortDirection]]] - A key
        or a list of (key, direction) pairs specifying the sort order
        for this query.
        :param projection_model: Optional[type[BaseModel]] - projection model
        :param session: Optional[AsyncClientSession] - pymongo session
        :param ignore_cache: bool
        :param **pymongo_kwargs: pymongo native parameters for find operation (if Document class contains links, this parameter must fit the respective parameter of the aggregate MongoDB function)
        :return: FindMany - query instance
        """
        self.find_expressions += args  # type: ignore # bool workaround
        self.skip(skip)
        self.limit(limit)
        self.sort(sort)
        self.project(projection_model)
        self.set_session(session=session)
        self.ignore_cache = ignore_cache
        self.fetch_links = fetch_links
        self.pymongo_kwargs.update(pymongo_kwargs)
        self.nesting_depth = nesting_depth
        self.nesting_depths_per_field = nesting_depths_per_field
        if lazy_parse is True:
            self.lazy_parse = lazy_parse
        return self

    # TODO probably merge FindOne and FindMany to one class to avoid this
    #  code duplication

    @overload
    def project(
        self: "FindMany",
        projection_model: None,
    ) -> "FindMany[FindQueryResultType]": ...

    @overload
    def project(
        self: "FindMany",
        projection_model: type[FindQueryProjectionType],
    ) -> "FindMany[FindQueryProjectionType]": ...

    def project(
        self: "FindMany",
        projection_model: type[FindQueryProjectionType] | None,
    ) -> Union[
        "FindMany[FindQueryResultType]", "FindMany[FindQueryProjectionType]"
    ]:
        """
        Apply projection parameter

        :param projection_model: Optional[type[BaseModel]] - projection model
        :return: self
        """
        super().project(projection_model)
        return self

    @overload
    def find(
        self: "FindMany[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: None = None,
        skip: int | None = None,
        limit: int | None = None,
        sort: None | str | list[tuple[str, SortDirection]] = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        lazy_parse: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> "FindMany[FindQueryResultType]": ...

    @overload
    def find(
        self: "FindMany[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: type[FindQueryProjectionType] | None = None,
        skip: int | None = None,
        limit: int | None = None,
        sort: None | str | list[tuple[str, SortDirection]] = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        lazy_parse: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> "FindMany[FindQueryProjectionType]": ...

    def find(
        self: "FindMany[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: type[FindQueryProjectionType] | None = None,
        skip: int | None = None,
        limit: int | None = None,
        sort: None | str | list[tuple[str, SortDirection]] = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        lazy_parse: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> Union[
        "FindMany[FindQueryResultType]", "FindMany[FindQueryProjectionType]"
    ]:
        """
        The same as `find_many(...)`
        """
        return self.find_many(
            *args,
            skip=skip,
            limit=limit,
            sort=sort,
            projection_model=projection_model,
            session=session,
            ignore_cache=ignore_cache,
            fetch_links=fetch_links or self.fetch_links,
            lazy_parse=lazy_parse,
            nesting_depth=nesting_depth,
            nesting_depths_per_field=nesting_depths_per_field,
            **pymongo_kwargs,
        )

    def sort(
        self,
        *args: (
            str
            | tuple[str, SortDirection]
            | list[tuple[str, SortDirection]]
            | None
        ),
    ) -> "FindMany[FindQueryResultType]":
        """
        Add sort parameters
        :param args: Union[str, Tuple[str, SortDirection],
        list[tuple[str, SortDirection]]] - A key or a tuple (key, direction)
        or a list of (key, direction) pairs specifying
        the sort order for this query.
        :return: self
        """
        for arg in args:
            if arg is None:
                pass
            elif isinstance(arg, list):
                self.sort(*arg)
            elif isinstance(arg, tuple):
                self.sort_expressions.append(arg)
            elif isinstance(arg, str):
                if arg.startswith("+"):
                    self.sort_expressions.append(
                        (arg[1:], SortDirection.ASCENDING)
                    )
                elif arg.startswith("-"):
                    self.sort_expressions.append(
                        (arg[1:], SortDirection.DESCENDING)
                    )
                else:
                    self.sort_expressions.append(
                        (arg, SortDirection.ASCENDING)
                    )
            else:
                raise TypeError("Wrong argument type")
        return self

    def skip(self, n: int | None) -> "FindMany[FindQueryResultType]":
        """
        Set skip parameter
        :param n: int
        :return: self
        """
        if n is not None:
            self.skip_number = n
        return self

    def limit(self, n: int | None) -> "FindMany[FindQueryResultType]":
        """
        Set limit parameter
        :param n: int
        :return:
        """
        if n is not None:
            self.limit_number = n
        return self

    def update(
        self,
        *args: Mapping[str, Any],
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        **pymongo_kwargs: Any,
    ):
        """
        Create Update with modifications query
        and provide search criteria there

        :param args: *Mapping[str,Any] - the modifications to apply.
        :param session: Optional[AsyncClientSession] - pymongo session
        :param bulk_writer: Optional[BulkWriter]
        :return: UpdateMany query
        """
        self.set_session(session)
        return (
            self.UpdateQueryType(
                document_model=self.document_model,
                find_query=self.get_filter_query(),
            )
            .update(*args, bulk_writer=bulk_writer, **pymongo_kwargs)
            .set_session(session=self.session)
        )

    def upsert(
        self,
        *args: Mapping[str, Any],
        on_insert: "DocType",
        session: AsyncClientSession | None = None,
        **pymongo_kwargs: Any,
    ):
        """
        Create Update with modifications query
        and provide search criteria there

        :param args: *Mapping[str,Any] - the modifications to apply.
        :param on_insert: DocType - document to insert if there is no matched
        document in the collection
        :param session: Optional[AsyncClientSession] - pymongo session
        :return: UpdateMany query
        """
        self.set_session(session)
        return (
            self.UpdateQueryType(
                document_model=self.document_model,
                find_query=self.get_filter_query(),
            )
            .upsert(
                *args,
                on_insert=on_insert,
                **pymongo_kwargs,
            )
            .set_session(session=self.session)
        )

    def update_many(
        self,
        *args: Mapping[str, Any],
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        **pymongo_kwargs: Any,
    ) -> UpdateMany:
        """
        Provide search criteria to the
        [UpdateMany](query.md#updatemany) query

        :param args: *Mapping[str,Any] - the modifications to apply.
        :param session: Optional[AsyncClientSession] - pymongo session
        :return: [UpdateMany](query.md#updatemany) query
        """
        return cast(
            UpdateMany,
            self.update(
                *args,
                session=session,
                bulk_writer=bulk_writer,
                **pymongo_kwargs,
            ),
        )

    def delete_many(
        self,
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        **pymongo_kwargs: Any,
    ) -> DeleteMany:
        """
        Provide search criteria to the [DeleteMany](query.md#deletemany) query

        :param session: Optional[AsyncClientSession] - pymongo session
        :return: [DeleteMany](query.md#deletemany) query
        """
        # We need to cast here to tell mypy that we are sure about the type.
        # This is because delete may also return a DeleteOne type in general, and mypy can not be sure in this case
        # See https://mypy.readthedocs.io/en/stable/common_issues.html#narrowing-and-inner-functions
        return cast(
            DeleteMany,
            self.delete(
                session=session, bulk_writer=bulk_writer, **pymongo_kwargs
            ),
        )

    @overload
    def aggregate(
        self,
        aggregation_pipeline: list[Any],
        projection_model: None = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        **pymongo_kwargs: Any,
    ) -> AggregationQuery[dict[str, Any]]: ...

    @overload
    def aggregate(
        self,
        aggregation_pipeline: list[Any],
        projection_model: type[FindQueryProjectionType],
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        **pymongo_kwargs: Any,
    ) -> AggregationQuery[FindQueryProjectionType]: ...

    def aggregate(
        self,
        aggregation_pipeline: list[dict[str, Any]],
        projection_model: type[FindQueryProjectionType] | None = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        **pymongo_kwargs: Any,
    ) -> (
        AggregationQuery[dict[str, Any]]
        | AggregationQuery[FindQueryProjectionType]
    ):
        """
        Provide search criteria to the [AggregationQuery](query.md#aggregationquery)

        :param aggregation_pipeline: list - aggregation pipeline. MongoDB doc:
        <https://docs.mongodb.com/manual/core/aggregation-pipeline/>
        :param projection_model: type[BaseModel] - Projection Model
        :param session: Optional[AsyncClientSession] - pymongo session
        :param ignore_cache: bool
        :return:[AggregationQuery](query.md#aggregationquery)
        """
        self.set_session(session=session)
        return self.AggregationQueryType(
            self.document_model,
            self.build_aggregation_pipeline(*aggregation_pipeline),
            find_query={},
            projection_model=projection_model,
            ignore_cache=ignore_cache,
            **pymongo_kwargs,
        ).set_session(session=self.session)

    @property
    def _cache_key(self) -> str:
        return LRUCache.create_key(
            {
                "type": "FindMany",
                "filter": self.get_filter_query(),
                "sort": self.sort_expressions,
                "projection": get_projection(self.projection_model),
                "skip": self.skip_number,
                "limit": self.limit_number,
            }
        )

    def _get_cache(self):
        if (
            self.document_model.get_settings().use_cache
            and self.ignore_cache is False
        ):
            return self.document_model._cache.get(self._cache_key)  # type: ignore
        else:
            return None

    def _set_cache(self, data):
        if (
            self.document_model.get_settings().use_cache
            and self.ignore_cache is False
        ):
            return self.document_model._cache.set(self._cache_key, data)  # type: ignore

    def build_aggregation_pipeline(
        self, *extra_stages: dict[str, Any]
    ) -> list[dict[str, Any]]:
        if self.fetch_links:
            aggregation_pipeline = construct_lookup_queries(
                self.document_model,
                nesting_depth=self.nesting_depth,
                nesting_depths_per_field=self.nesting_depths_per_field,
            )
        else:
            aggregation_pipeline = []
        filter_query = self.get_filter_query()

        if filter_query:
            text_queries, non_text_queries = split_text_query(filter_query)

            if text_queries:
                aggregation_pipeline.insert(
                    0,
                    {
                        "$match": (
                            {"$and": text_queries}
                            if len(text_queries) > 1
                            else text_queries[0]
                        )
                    },
                )

            if non_text_queries:
                aggregation_pipeline.append(
                    {
                        "$match": (
                            {"$and": non_text_queries}
                            if len(non_text_queries) > 1
                            else non_text_queries[0]
                        )
                    }
                )

        if extra_stages:
            aggregation_pipeline.extend(extra_stages)
        sort_pipeline = {"$sort": {i[0]: i[1] for i in self.sort_expressions}}
        if sort_pipeline["$sort"]:
            aggregation_pipeline.append(sort_pipeline)
        if self.skip_number != 0:
            aggregation_pipeline.append({"$skip": self.skip_number})
        if self.limit_number != 0:
            aggregation_pipeline.append({"$limit": self.limit_number})
        return aggregation_pipeline

    async def get_cursor(
        self,
    ) -> "AsyncCommandCursor[dict[str, Any]] | AsyncCursor[dict[str, Any]] | None":
        if self.fetch_links:
            aggregation_pipeline = self.build_aggregation_pipeline()
            projection = get_projection(self.projection_model)

            if projection is not None:
                aggregation_pipeline.append({"$project": projection})

            return (
                await self.document_model.get_pymongo_collection().aggregate(
                    aggregation_pipeline,
                    session=self.session,
                    **self.pymongo_kwargs,
                )
            )

        return self.document_model.get_pymongo_collection().find(
            filter=self.get_filter_query(),
            sort=self.sort_expressions,
            projection=get_projection(self.projection_model),
            skip=self.skip_number,
            limit=self.limit_number,
            session=self.session,
            **self.pymongo_kwargs,
        )

    async def first_or_none(self) -> FindQueryResultType | None:
        """
        Returns the first found element or None if no elements were found
        """
        existing_limit = self.limit_number
        try:
            result = await self.limit(1).to_list()
            return result[0] if result else None
        finally:
            self.limit_number = existing_limit

    async def count(self) -> int:
        """
        Number of found documents
        :return: int
        """
        if self.fetch_links:
            aggregation_pipeline = self.build_aggregation_pipeline()
            aggregation_pipeline.append({"$count": "count"})
            cursor = (
                await self.document_model.get_pymongo_collection().aggregate(
                    aggregation_pipeline,
                    session=self.session,
                    **self.pymongo_kwargs,
                )
            )
            result = await cursor.to_list(length=1)

            return result[0]["count"] if result else 0

        return await super().count()

    async def distinct(
        self,
        key: Any,
        session: AsyncClientSession | None = None,
        **kwargs: Any,
    ) -> list[Any]:
        """
        Get a list of distinct values for `key` among documents matching
        the query filter.  When ``fetch_links`` is enabled the query is
        executed via an aggregation pipeline so that ``$lookup`` stages
        are included.

        Sort, skip and limit stages are excluded from the pipeline
        because MongoDB's distinct command does not support pagination
        and distinct values are order-independent.

        :param key: Field name for which to return distinct values.
        :param session: Optional pymongo session. Defaults to None.
        :return: List of distinct values.
        """
        if self.fetch_links:
            aggregation_pipeline = [
                *(
                    stage
                    for stage in self.build_aggregation_pipeline()
                    if "$sort" not in stage
                    and "$skip" not in stage
                    and "$limit" not in stage
                ),
                {
                    "$unwind": {
                        "path": f"${key}",
                        "preserveNullAndEmptyArrays": True,
                    }
                },
                {
                    "$group": {
                        "_id": None,
                        "distinct": {"$addToSet": f"${key}"},
                    }
                },
            ]
            kwargs = {**self.pymongo_kwargs, **kwargs}
            cursor = (
                await self.document_model.get_pymongo_collection().aggregate(
                    aggregation_pipeline,
                    session=session or self.session,
                    **kwargs,
                )
            )
            result = await cursor.to_list(length=1)
            return result[0]["distinct"] if result else []

        kwargs = {**self.pymongo_kwargs, **kwargs}
        return await self.document_model.get_pymongo_collection().distinct(
            key=key,
            filter=self.get_filter_query(),
            session=session or self.session,
            **kwargs,
        )


class FindOne(FindQuery[FindQueryResultType]):
    """
    Find One query class
    """

    UpdateQueryType = UpdateOne
    DeleteQueryType = DeleteOne

    @overload
    def project(
        self: "FindOne[FindQueryResultType]",
        projection_model: None = None,
    ) -> "FindOne[FindQueryResultType]": ...

    @overload
    def project(
        self: "FindOne[FindQueryResultType]",
        projection_model: type[FindQueryProjectionType],
    ) -> "FindOne[FindQueryProjectionType]": ...

    # TODO probably merge FindOne and FindMany to one class to avoid this
    #  code duplication

    def project(
        self: "FindOne[FindQueryResultType]",
        projection_model: type[FindQueryProjectionType] | None = None,
    ) -> Union[
        "FindOne[FindQueryResultType]", "FindOne[FindQueryProjectionType]"
    ]:
        """
        Apply projection parameter
        :param projection_model: Optional[type[BaseModel]] - projection model
        :return: self
        """
        super().project(projection_model)
        return self

    @overload
    def find_one(
        self: "FindOne[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: None = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> "FindOne[FindQueryResultType]": ...

    @overload
    def find_one(
        self: "FindOne[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: type[FindQueryProjectionType],
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> "FindOne[FindQueryProjectionType]": ...

    def find_one(
        self: "FindOne[FindQueryResultType]",
        *args: Mapping[Any, Any] | bool,
        projection_model: type[FindQueryProjectionType] | None = None,
        session: AsyncClientSession | None = None,
        ignore_cache: bool = False,
        fetch_links: bool = False,
        nesting_depth: int | None = None,
        nesting_depths_per_field: dict[str, int] | None = None,
        **pymongo_kwargs: Any,
    ) -> Union[
        "FindOne[FindQueryResultType]", "FindOne[FindQueryProjectionType]"
    ]:
        """
        Find one document by criteria

        :param args: *Mapping[Any, Any] - search criteria
        :param projection_model: Optional[type[BaseModel]] - projection model
        :param session: Optional[AsyncClientSession] - pymongo session
        :param ignore_cache: bool
        :param **pymongo_kwargs: pymongo native parameters for find operation (if Document class contains links, this parameter must fit the respective parameter of the aggregate MongoDB function)
        :return: FindOne - query instance
        """
        self.find_expressions += args  # type: ignore # bool workaround
        self.project(projection_model)
        self.set_session(session=session)
        self.ignore_cache = ignore_cache
        self.fetch_links = fetch_links or self.fetch_links
        self.pymongo_kwargs.update(pymongo_kwargs)
        self.nesting_depth = nesting_depth
        self.nesting_depths_per_field = nesting_depths_per_field
        return self

    def update(
        self,
        *args: Mapping[str, Any],
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        response_type: UpdateResponse | None = None,
        **pymongo_kwargs: Any,
    ):
        """
        Create Update with modifications query
        and provide search criteria there

        :param args: *Mapping[str,Any] - the modifications to apply.
        :param session: Optional[AsyncClientSession] - pymongo session
        :param bulk_writer: Optional[BulkWriter]
        :param response_type: Optional[UpdateResponse]
        :return: UpdateMany query
        """
        self.set_session(session)
        return (
            self.UpdateQueryType(
                document_model=self.document_model,
                find_query=self.get_filter_query(),
            )
            .update(
                *args,
                bulk_writer=bulk_writer,
                response_type=response_type,
                **pymongo_kwargs,
            )
            .set_session(session=self.session)
        )

    def upsert(
        self,
        *args: Mapping[str, Any],
        on_insert: "DocType",
        session: AsyncClientSession | None = None,
        response_type: UpdateResponse | None = None,
        **pymongo_kwargs: Any,
    ):
        """
        Create Update with modifications query
        and provide search criteria there

        :param args: *Mapping[str,Any] - the modifications to apply.
        :param on_insert: DocType - document to insert if there is no matched
        document in the collection
        :param session: Optional[AsyncClientSession] - pymongo session
        :param response_type: Optional[UpdateResponse]
        :return: UpdateMany query
        """
        self.set_session(session)
        return (
            self.UpdateQueryType(
                document_model=self.document_model,
                find_query=self.get_filter_query(),
            )
            .upsert(
                *args,
                on_insert=on_insert,
                response_type=response_type,
                **pymongo_kwargs,
            )
            .set_session(session=self.session)
        )

    def update_one(
        self,
        *args: Mapping[str, Any],
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        response_type: UpdateResponse | None = None,
        **pymongo_kwargs: Any,
    ) -> UpdateOne:
        """
        Create [UpdateOne](query.md#updateone) query using modifications and
        provide search criteria there
        :param args: *Mapping[str,Any] - the modifications to apply
        :param session: Optional[AsyncClientSession] - pymongo session
        :param response_type: Optional[UpdateResponse]
        :return: [UpdateOne](query.md#updateone) query
        """
        return cast(
            UpdateOne,
            self.update(
                *args,
                session=session,
                bulk_writer=bulk_writer,
                response_type=response_type,
                **pymongo_kwargs,
            ),
        )

    def delete_one(
        self,
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
        **pymongo_kwargs: Any,
    ) -> DeleteOne:
        """
        Provide search criteria to the [DeleteOne](query.md#deleteone) query
        :param session: Optional[AsyncClientSession] - pymongo session
        :return: [DeleteOne](query.md#deleteone) query
        """
        # We need to cast here to tell mypy that we are sure about the type.
        # This is because delete may also return a DeleteOne type in general, and mypy can not be sure in this case
        # See https://mypy.readthedocs.io/en/stable/common_issues.html#narrowing-and-inner-functions
        return cast(
            DeleteOne,
            self.delete(
                session=session, bulk_writer=bulk_writer, **pymongo_kwargs
            ),
        )

    async def replace_one(
        self,
        document: "DocType",
        session: AsyncClientSession | None = None,
        bulk_writer: BulkWriter | None = None,
    ) -> UpdateResult | None:
        """
        Replace found document by provided
        :param document: Document - document, which will replace the found one
        :param session: Optional[AsyncClientSession] - pymongo session
        :param bulk_writer: Optional[BulkWriter] - Beanie bulk writer
        :return: UpdateResult
        """
        self.set_session(session=session)
        if bulk_writer is None:
            result: UpdateResult = (
                await self.document_model.get_pymongo_collection().replace_one(
                    self.get_filter_query(),
                    get_dict(
                        document,
                        to_db=True,
                        exclude={"_id"},
                        keep_nulls=document.get_settings().keep_nulls,
                    ),
                    session=self.session,
                )
            )

            if not result.raw_result["updatedExisting"]:
                raise DocumentNotFound
            return result
        else:
            bulk_writer.add_operation(
                self.document_model,
                ReplaceOne(
                    self.get_filter_query(),
                    get_dict(
                        document,
                        to_db=True,
                        exclude={"_id"},
                        keep_nulls=document.get_settings().keep_nulls,
                    ),
                    **self.pymongo_kwargs,
                ),
            )
            return None

    async def _find_one(self):
        if self.fetch_links:
            return await self.document_model.find_many(
                *self.find_expressions,
                session=self.session,
                fetch_links=self.fetch_links,
                projection_model=self.projection_model,
                nesting_depth=self.nesting_depth,
                nesting_depths_per_field=self.nesting_depths_per_field,
                **self.pymongo_kwargs,
            ).first_or_none()
        return await self.document_model.get_pymongo_collection().find_one(
            filter=self.get_filter_query(),
            projection=get_projection(self.projection_model),
            session=self.session,
            **self.pymongo_kwargs,
        )

    def __await__(
        self,
    ) -> Generator[Coroutine, Any, FindQueryResultType | None]:
        """
        Run the query
        :return: BaseModel
        """
        # projection = get_projection(self.projection_model)
        if (
            self.document_model.get_settings().use_cache
            and self.ignore_cache is False
        ):
            cache_key = LRUCache.create_key(
                "FindOne",
                self.get_filter_query(),
                self.projection_model,
                self.session,
                self.fetch_links,
            )
            document: dict[str, Any] = self.document_model._cache.get(  # type: ignore
                cache_key
            )
            if document is None:
                document = yield from self._find_one().__await__()  # type: ignore
                self.document_model._cache.set(cache_key, document)  # type: ignore
        else:
            document = yield from self._find_one().__await__()  # type: ignore
        if document is None:
            return None
        if type(document) is self.projection_model:
            return cast(FindQueryResultType, document)
        return cast(
            FindQueryResultType, parse_obj(self.projection_model, document)
        )

    async def count(self) -> int:
        """
        Count the number of documents matching the query
        :return: int
        """
        if self.fetch_links:
            return await self.document_model.find_many(
                *self.find_expressions,
                session=self.session,
                fetch_links=self.fetch_links,
                **self.pymongo_kwargs,
            ).count()
        return await super().count()
