import pytest
from pydantic_settings import BaseSettings
from pymongo import AsyncMongoClient


class Settings(BaseSettings):
    mongodb_dsn: str = "mongodb://localhost:27017/beanie_db"
    mongodb_db_name: str = "beanie_db"


@pytest.fixture(scope="session")
def settings():
    return Settings()


@pytest.fixture(scope="session")
async def cli(settings):
    async with AsyncMongoClient(settings.mongodb_dsn) as client:
        yield client


@pytest.fixture(scope="session")
def db(cli, settings):
    return cli[settings.mongodb_db_name]
