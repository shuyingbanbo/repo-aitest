=============================
 reStructuredText Directives
=============================
:Author: David Goodger
:Contact: docutils-develop@lists.sourceforge.net
:Revision: $Revision: 8959 $
:Date: $Date: 2022-01-21 14:45:42 +0100 (Fr, 21. Jan 2022) $
:Copyright: This document has been placed in the public domain.

.. contents::
   :depth: 2

This document describes the directives implemented in the reference
reStructuredText parser.

Directives have the following syntax::

    +-------+-------------------------------+
    | ".. " | directive type "::" directive |
    +-------+ block                         |
            |                               |
            +-------------------------------+

Directives begin with an explicit markup start (two periods and a
space), followed by the directive type and two colons (collectively,
the "directive marker").  The directive block begins immediately after
the directive marker, and includes all subsequent indented lines.  The
directive block is divided into arguments, options (a field list), and
content (in that order), any of which may appear.  See the Directives_
section in the `reStructuredText Markup Specification`_ for syntax
details.

Descriptions below list "doctree elements" (document tree element
names; XML DTD generic identifiers) corresponding to individual
directives.  For details on the hierarchy of elements, please see `The
Docutils Document Tree`_ and the `Docutils Generic DTD`_ XML document
type definition.  For directive implementation details, see `Creating
reStructuredText Directives`_.

.. _Directives: restructuredtext.html#directives
.. _reStructuredText Markup Specification: restructuredtext.html
.. _The Docutils Document Tree: ../doctree.html
.. _Docutils Generic DTD: ../docutils.dtd
.. _Creating reStructuredText Directives:
   ../../howto/rst-directives.html


-------------
 Admonitions
-------------

.. From Webster's Revised Unabridged Dictionary (1913) [web1913]:
   Admonition
      Gentle or friendly reproof; counseling against a fault or
      error; expression of authoritative advice; friendly caution
      or warning.

      Syn: {Admonition}, {Reprehension}, {Reproof}.

      Usage: Admonition is prospective, and relates to moral delinquencies;
             its object is to prevent further transgression.

.. _attention:
.. _caution:
.. _danger:
.. _error:
.. _hint:
.. _important:
.. _note:
.. _tip:
.. _warning:

Specific Admonitions
====================

:Directive Types: "attention", "caution", "danger", "error", "hint",
                  "important", "note", "tip", "warning", "admonition"
:Doctree Elements: attention, caution, danger, error, hint, important,
                   note, tip, warning, admonition_, title_
:Directive Arguments: None.
:Directive Options: class_, name_
:Directive Content: Interpreted as body elements.

Admonitions are specially marked "topics" that can appear anywhere an
ordinary body element can.  They contain arbitrary body elements.
Typically, an admonition is rendered as an offset block in a document,
sometimes outlined or shaded, with a title matching the admonition
type.  For example::

    .. DANGER::
       Beware killer rabbits!

This directive might be rendered something like this::

    +------------------------+
    |        !DANGER!        |
    |                        |
    | Beware killer rabbits! |
    +------------------------+

The following admonition directives have been implemented:

- attention
- caution
- danger
- error
- hint
- important
- note
- tip
- warning

Any text immediately following the directive indicator (on the same
line and/or indented on following lines) is interpreted as a directive
block and is parsed for normal body elements.  For example, the
following "note" admonition directive contains one paragraph and a
bullet list consisting of two list items::

    .. note:: This is a note admonition.
       This is the second line of the first paragraph.

       - The note contains all indented body elements
         following.
       - It includes this bullet list.


Generic Admonition
==================

:Directive Type: "admonition"
:Doctree Elements: admonition_, title_
:Directive Arguments: One, required (admonition title)
:Directive Options: class_, name_
:Directive Content: Interpreted as body elements.

This is a generic, titled admonition.  The title may be anything the
author desires.

The author-supplied title is also used as a `"classes"`_ attribute value
after being converted into a valid identifier form (down-cased;
non-alphanumeric characters converted to single hyphens; "admonition-"
prefixed).  For example, this admonition::

    .. admonition:: And, by the way...

       You can make up your own admonition too.

becomes the following document tree (pseudo-XML)

.. code-block:: xml

    <document source="test data">
        <admonition classes="admonition-and-by-the-way">
            <title>
                And, by the way...
            <paragraph>
                You can make up your own admonition too.

The class_ option overrides the computed `"classes"`_ attribute
value.


--------
 Images
--------

There are two image directives: "image" and "figure".

It is up to the author to ensure compatibility of the image data format
with the output format or user agent (LaTeX__ engine, `HTML5 browser`__,
ODT, ...). The following, non exhaustive table provides an overview

.. [#] The html5 writer uses the ``<video>`` tag if the image URI points
       to a file with an extension matching one of the listed video formats
       (since Docutils 0.17).

.. [#] The html4 writer uses an ``<object>`` tag for SVG images for better
       compatibility with older browsers.

.. [#] When compiling with ``pdflatex``, ``xelatex``, or ``lualatex``.
       The original ``latex`` engine supports only the EPS image format.
       Some build systems, e.g. rubber_ support additional formats via
       on-the-fly image conversion.

__ ../../user/latex.html#image-inclusion
__ https://developer.mozilla.org/en-US/docs/Web/Media/Formats/Image_types
.. _rubber: https://github.com/petrhosek/rubber

Image
=====

:Directive Type: "image"
:Doctree Element: image_
:Directive Arguments: One, required (image URI).
:Directive Options: Possible (see below).
:Directive Content: None.

An "image" is a simple picture::

    .. image:: picture.png

Inline images can be defined with an "image" directive in a `substitution
definition`_

The URI for the image source file is specified in the directive
argument.  As with hyperlink targets, the image URI may begin on the
same line as the explicit markup start and target name, or it may
begin in an indented text block immediately following, with no
intervening blank lines.  If there are multiple lines in the link
block, they are stripped of leading and trailing whitespace and joined
together.

Optionally, the image link block may contain a flat field list, the
_`image options`.  For example::

    .. image:: picture.jpeg
       :height: 100px
       :width: 200 px
       :scale: 50 %
       :alt: alternate text
       :align: right

The following options are recognized:

``alt`` : text
    Alternate text: a short description of the image, displayed by
    applications that cannot display images, or spoken by applications
    for visually impaired users.

``height`` : `length`_
    The desired height of the image.
    Used to reserve space or scale the image vertically.  When the "scale"
    option is also specified, they are combined.  For example, a height of
    200px and a scale of 50 is equivalent to a height of 100px with no scale.

``width`` : `length`_ or `percentage`_ of the current line width
    The width of the image.
    Used to reserve space or scale the image horizontally.  As with "height"
    above, when the "scale" option is also specified, they are combined.

``scale`` : integer percentage (the "%" symbol is optional)
    The uniform scaling factor of the image.  The default is "100Â %", i.e.
    no scaling.

    If no "height" or "width" options are specified, the `Python
    Imaging Library` (PIL/Pillow_) may be used to determine them, if
    it is installed and the image file is available.

``align`` : "top", "middle", "bottom", "left", "center", or "right"
    The alignment of the image, equivalent to the HTML ``<img>`` tag's
    deprecated "align" attribute or the corresponding "vertical-align" and
    "text-align" CSS properties.
    The values "top", "middle", and "bottom"
    control an image's vertical alignment (relative to the text
    baseline); they are only useful for inline images (substitutions).
    The values "left", "center", and "right" control an image's
    horizontal alignment, allowing the image to float and have the
    text flow around it.  The specific behavior depends upon the
    browser or rendering software used.

``target`` : text (URI or reference name)
    Makes the image into a hyperlink reference ("clickable").  The
    option argument may be a URI (relative or absolute), or a
    `reference name`_ with underscore suffix (e.g. ```a name`_``).

and the common options class_ and name_.


Figure
======

:Directive Type: "figure"
:Doctree Elements: figure_, image_, caption_, legend_
:Directive Arguments: One, required (image URI).
:Directive Options: Possible (see below).
:Directive Content: Interpreted as the figure caption and an optional
                    legend.

A "figure" consists of image_ data (including `image options`_), an optional
caption (a single paragraph), and an optional legend (arbitrary body
elements). For page-based output media, figures might float to a different
position if this helps the page layout.
::

    .. figure:: picture.png
       :scale: 50 %
       :alt: map to buried treasure

       This is the caption of the figure (a simple paragraph).

There must be blank lines before the caption paragraph and before the
legend.  To specify a legend without a caption, use an empty comment
("..") in place of the caption.

The "figure" directive supports all of the options of the "image"
directive (see `image options`_ above). These options (except
"align") are passed on to the contained image.

``align`` : "left", "center", or "right"
    The horizontal alignment of the figure, allowing the image to
    float and have the text flow around it.  The specific behavior
    depends upon the browser or rendering software used.

In addition, the following options are recognized:

``figwidth`` : "image", length_, or percentage_ of current line width
    The width of the figure.
    Limits the horizontal space used by the figure.
    A special value of "image" is allowed, in which case the
    included image's actual width is used (requires the `Python Imaging
    Library`_). If the image file is not found or the required software is
    unavailable, this option is ignored.

    Sets the "width" attribute of the "figure" doctree element.

    This option does not scale the included image; use the "width"
    `image`_ option for that.

``figclass`` : text
    Set a `"classes"`_ attribute value on the figure element.  See the
    class_ directive below.

.. _Python Imaging Library:
.. _Pillow: https://pypi.org/project/Pillow/


---------------
 Body Elements
---------------

Topic
=====

:Directive Type: "topic"
:Doctree Element: topic_
:Directive Arguments: One, required (topic title).
:Directive Options: class_, name_
:Directive Content: Interpreted as the topic body.

A topic is like a block quote with a title, or a self-contained
section with no subsections.  Use the "topic" directive to indicate a
self-contained idea that is separate from the flow of the document.
Topics may occur anywhere a section or transition may occur.  Body
elements and topics may not contain nested topics.

The directive's sole argument is interpreted as the topic title; the
next line must be blank.  All subsequent lines make up the topic body,
interpreted as body elements.  For example::

    .. topic:: Topic Title

        Subsequent indented lines comprise
        the body of the topic, and are
        interpreted as body elements.


Sidebar
=======

:Directive Type: "sidebar"
:Doctree Element: sidebar_
:Directive Arguments: One, optional (sidebar title).
:Directive Options: Possible (see below).
:Directive Content: Interpreted as the sidebar body.

Sidebars are like miniature, parallel documents that occur inside
other documents, providing related or reference material.  A sidebar
is typically offset by a border and "floats" to the side of the page;
the document's main text may flow around it.  Sidebars can also be
likened to super-footnotes; their content is outside of the flow of
the document's main text.

Sidebars may occur anywhere a section or transition may occur.  Body
elements (including sidebars) may not contain nested sidebars.

The directive's sole argument is interpreted as the sidebar title,
which may be followed by a subtitle option (see below); the next line
must be blank.  All subsequent lines make up the sidebar body,
interpreted as body elements.  For example::

    .. sidebar:: Optional Sidebar Title
       :subtitle: Optional Sidebar Subtitle

       Subsequent indented lines comprise
       the body of the sidebar, and are
       interpreted as body elements.

The following options are recognized:

``subtitle`` : text
    The sidebar's subtitle.

and the common options class_ and name_.


Line Block
==========

.. admonition:: Deprecated

   The "line-block" directive is deprecated.  Use the `line block
   syntax`_ instead.

   .. _line block syntax: restructuredtext.html#line-blocks

:Directive Type: "line-block"
:Doctree Element: line_block_
:Directive Arguments: None.
:Directive Options: class_, name_
:Directive Content: Becomes the body of the line block.

The "line-block" directive constructs an element where line breaks and
initial indentation is significant and inline markup is supported.  It
is equivalent to a `parsed literal block`_ with different rendering:
typically in an ordinary serif typeface instead of a
typewriter/monospaced face, and not automatically indented.  (Have the
line-block directive begin a block quote to get an indented line
block.)  Line blocks are useful for address blocks and verse (poetry,
song lyrics), where the structure of lines is significant.  For
example, here's a classic::

    "To Ma Own Beloved Lassie: A Poem on her 17th Birthday", by
    Ewan McTeagle (for Lassie O'Shea):

        .. line-block::

            Lend us a couple of bob till Thursday.
            I'm absolutely skint.
            But I'm expecting a postal order and I can pay you back
                as soon as it comes.
            Love, Ewan.



.. _parsed-literal:

Parsed Literal Block
====================

:Directive Type: "parsed-literal"
:Doctree Element: literal_block_
:Directive Arguments: None.
:Directive Options: class_, name_
:Directive Content: Becomes the body of the literal block.

Unlike an ordinary literal block, the "parsed-literal" directive
constructs a literal block where the text is parsed for inline markup.
It is equivalent to a `line block`_ with different rendering:
typically in a typewriter/monospaced typeface, like an ordinary
literal block.  Parsed literal blocks are useful for adding hyperlinks
to code examples.

However, care must be taken with the text, because inline markup is
recognized and there is no protection from parsing.  Backslash-escapes
may be necessary to prevent unintended parsing.  And because the
markup characters are removed by the parser, care must also be taken
with vertical alignment.  Parsed "ASCII art" is tricky, and extra
whitespace may be necessary.

For example, all the element names in this content model are links::

    .. parsed-literal::

       ( (title_, subtitle_?)?,
         decoration_?,
         (docinfo_, transition_?)?,
         `%structure.model;`_ )

Code
====

:Directive Type: "code"
:Doctree Element: literal_block_, `inline elements`_
:Directive Arguments: One, optional (formal language).
:Directive Options: name, class, number-lines.
:Directive Content: Becomes the body of the literal block.
:Configuration Setting: syntax_highlight_.

The "code" directive constructs a literal block. If the code language is
specified, the content is parsed by the Pygments_ syntax highlighter and
tokens are stored in nested `inline elements`_ with class arguments
according to their syntactic category. The actual highlighting requires
a style-sheet (e.g. one `generated by Pygments`__, see the
`sandbox/stylesheets`__ for examples).

The parsing can be turned off with the syntax_highlight_ configuration
setting and command line option or by specifying the language as class_
option instead of directive argument. This also avoids warnings
when Pygments_ is not installed or the language is not in the
`supported languages and markup formats`_.

For inline code, use the `"code" role`_.

__ https://pygments.org/docs/cmdline/#generating-styles
__ https://docutils.sourceforge.io/sandbox/stylesheets/
.. _Pygments: https://pygments.org/
.. _syntax_highlight: ../../user/config.html#syntax-highlight
.. _supported languages and markup formats: https://pygments.org/languages/
.. _"code" role: roles.html#code


The following options are recognized:

``number-lines`` : [integer] (start line number)
    Precede every line with a line number.
    The optional argument is the number of the first line (default 1).

and the common options class_ and name_.

Example::

  The content of the following directive ::

    .. code:: python

      def my_function():
          "just a test"
          print 8/2

  is parsed and marked up as Python source code.


Math
====

:Directive Type: "math"
:Doctree Element: math_block_
:Directive Arguments: None.
:Directive Options: class_, name_
:Directive Content: Becomes the body of the math block.
                    (Content blocks separated by a blank line are put in
                    adjacent math blocks.)
:Configuration Setting: math_output_

The "math" directive inserts blocks with mathematical content
(display formulas, equations) into the document. The input format is
`LaTeX math syntax`_ with support for Unicode symbols, for example::

  .. math::

    Î±_t(i) = P(O_1, O_2, â€¦ O_t, q_t = S_i Î»)

Support is limited to a subset of *LaTeX math* by the conversion
required for many output formats.  For HTML, the `math_output`_
configuration setting (or the corresponding ``--math-output``
command line option) select between alternative output formats with
different subsets of supported elements. If a writer does not
support math typesetting, the content is inserted verbatim.

For inline formulas, use the `"math" role`_.

.. _LaTeX math syntax: ../../ref/rst/mathematics.html
.. _"math" role: roles.html#math
.. _math_output: ../../user/config.html#math-output


Rubric
======

:Directive Type: "rubric"
:Doctree Element: rubric_
:Directive Arguments: One, required (rubric text).
:Directive Options: class_, name_
:Directive Content: None.

..

     rubric n. 1. a title, heading, or the like, in a manuscript,
     book, statute, etc., written or printed in red or otherwise
     distinguished from the rest of the text. ...

     -- Random House Webster's College Dictionary, 1991

The "rubric" directive inserts a "rubric" element into the document
tree.  A rubric is like an informal heading that doesn't correspond to
the document's structure.


Epigraph
========

:Directive Type: "epigraph"
:Doctree Element: block_quote_
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as the body of the block quote.

An epigraph is an apposite (suitable, apt, or pertinent) short
inscription, often a quotation or poem, at the beginning of a document
or section.

The "epigraph" directive produces an "epigraph"-class block quote.
For example, this input::

     .. epigraph::

        No matter where you go, there you are.

        -- Buckaroo Banzai

becomes this document tree fragment::

    <block_quote classes="epigraph">
        <paragraph>
            No matter where you go, there you are.
        <attribution>
            Buckaroo Banzai


Highlights
==========

:Directive Type: "highlights"
:Doctree Element: block_quote_
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as the body of the block quote.

Highlights summarize the main points of a document or section, often
consisting of a list.

The "highlights" directive produces a "highlights"-class block quote.
See Epigraph_ above for an analogous example.


Pull-Quote
==========

:Directive Type: "pull-quote"
:Doctree Element: block_quote_
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as the body of the block quote.

A pull-quote is a small selection of text "pulled out and quoted",
typically in a larger typeface.  Pull-quotes are used to attract
attention, especially in long articles.

The "pull-quote" directive produces a "pull-quote"-class block quote.
See Epigraph_ above for an analogous example.


Compound Paragraph
==================

:Directive Type: "compound"
:Doctree Element: compound_
:Directive Arguments: None.
:Directive Options: class_, name_
:Directive Content: Interpreted as body elements.

The "compound" directive is used to create a compound paragraph, which
is a single logical paragraph containing multiple physical body
elements such as simple paragraphs, literal blocks, tables, lists,
etc., instead of directly containing text and inline elements.  For
example::

    .. compound::

       The 'rm' command is very dangerous.  If you are logged
       in as root and enter ::

           cd /
           rm -rf *

       you will erase the entire contents of your file system.

In the example above, a literal block is "embedded" within a sentence
that begins in one physical paragraph and ends in another.

.. note::

   The "compound" directive is *not* a generic block-level container
   like HTML's ``<div>`` element.  Do not use it only to group a
   sequence of elements, or you may get unexpected results.

   If you need a generic block-level container, please use the
   container_ directive, described below.

Compound paragraphs are typically rendered as multiple distinct text
blocks, with the possibility of variations to emphasize their logical
unity:

* If paragraphs are rendered with a first-line indent, only the first
  physical paragraph of a compound paragraph should have that indent
  -- second and further physical paragraphs should omit the indents;
* vertical spacing between physical elements may be reduced;
* and so on.


Container
=========

:Directive Type: "container"
:Doctree Element: `container <container element_>`__
:Directive Arguments: One or more, optional (class names).
:Directive Options: name_
:Directive Content: Interpreted as body elements.

The "container" directive surrounds its contents (arbitrary body
elements) with a generic block-level "container" element.  Combined
with the optional "classes_" attribute argument(s), this is an
extension mechanism for users & applications.  For example::

    .. container:: custom

       This paragraph might be rendered in a custom way.

Parsing the above results in the following pseudo-XML

.. code-block:: xml

    <container classes="custom">
        <paragraph>
            This paragraph might be rendered in a custom way.

The "container" directive is the equivalent of HTML's ``<div>``
element.  It may be used to group a sequence of elements for user- or
application-specific purposes.



--------
 Tables
--------

Formal tables need more structure than the reStructuredText syntax
supplies.  Tables may be given titles with the table_ directive.
Sometimes reStructuredText tables are inconvenient to write, or table
data in a standard format is readily available.  The csv-table_
directive supports CSV data.


Table
=====

:Directive Type: "table"
:Doctree Element: table_
:Directive Arguments: One, optional (table title).
:Directive Options: Possible (see below).
:Directive Content: A normal `reStructuredText table`_.

The "table" directive is used to associate a
title with a table or specify options, e.g.::

    .. table:: Truth table for "not"
       :widths: auto

       =====  =====
         A    not A
       =====  =====
       False  True
       True   False
       =====  =====

The following options are recognized:

``align`` : "left", "center", or "right"
    The horizontal alignment of the table (new in Docutils 0.13).

``width`` : `length`_ or `percentage`_
    Sets the width of the table to the specified length or percentage
    of the line width.  If omitted, the renderer determines the width
    of the table based on its contents or the column ``widths``.

    .. _column-widths:

``widths`` : "auto", "grid", or a list of integers
    A list of relative column widths.
    The default is the width of the input columns (in characters).

    *"auto"* delegates the determination of column widths to the backend
    (LaTeX, the HTML browser, ...).

    *"grid"* restores the default, overriding a `table_style`_ or class
    value "colwidths-auto".

Plus the common options class_ and name_.

.. _reStructuredText table: restructuredtext.html#tables
.. _table_style: ../../user/config.html#table-style


.. _csv-table:

CSV Table
=========

:Directive Type: "csv-table"
:Doctree Element: table_
:Directive Arguments: One, optional (table title).
:Directive Options: Possible (see below).
:Directive Content: A CSV (comma-separated values) table.

.. WARNING::

   The "csv-table" directive's ":file:" and ":url:" options represent
   a potential security holes.  They can be disabled with the
   "file_insertion_enabled_" runtime setting.

The "csv-table" directive is used to create a table from CSV
(comma-separated values) data.  CSV is a common data format generated
by spreadsheet applications and commercial databases.  The data may be
internal (an integral part of the document) or external (a separate
file).

* Block markup and inline markup within cells is supported.  Line ends
  are recognized within cells.

* There is no support for checking that the number of columns in each
  row is the same. The directive automatically adds empty entries at
  the end of short rows.

  .. Add "strict" option to verify input?

Example::

    .. csv-table:: Frozen Delights!
       :header: "Treat", "Quantity", "Description"
       :widths: 15, 10, 30

       "Albatross", 2.99, "On a stick!"
       "Crunchy Frog", 1.49, "If we took the bones out, it wouldn't be
       crunchy, now would it?"
       "Gannet Ripple", 1.99, "On a stick!"

The following options are recognized:

``align`` : "left", "center", or "right"
    The horizontal alignment of the table. (New in Docutils 0.13)

``delim`` : char | "tab" | "space" [#whitespace-delim]_
    A one-character string\ [#ASCII-char]_ used to separate fields.
    Defaults to ``,`` (comma).  May be specified as a Unicode code
    point; see the unicode_ directive for syntax details.

``encoding`` : string
    The text encoding of the external CSV data (file or URL).
    Defaults to the document's input_encoding_.

``escape`` : char
    A one-character\ [#ASCII-char]_ string used to escape the
    delimiter or quote characters.  May be specified as a Unicode
    code point; see the unicode_ directive for syntax details.  Used
    when the delimiter is used in an unquoted field, or when quote
    characters are used within a field.  The default is to double-up
    the character, e.g. "He said, ""Hi!"""

    .. Add another possible value, "double", to explicitly indicate
       the default case?

``file`` : string (newlines removed)
    The local filesystem path to a CSV data file.

``header`` : CSV data
    Supplemental data for the table header, added independently of and
    before any ``header-rows`` from the main CSV data.  Must use the
    same CSV format as the main CSV data.

``header-rows`` : integer
    The number of rows of CSV data to use in the table header.
    Defaults to 0.

``keepspace`` : flag (empty)
    Treat whitespace immediately following the delimiter as
    significant.  The default is to ignore such whitespace.

``quote`` : char
    A one-character string\ [#ASCII-char]_ used to quote elements
    containing the delimiter or which start with the quote
    character.  Defaults to ``"`` (quote).  May be specified as a
    Unicode code point; see the unicode_ directive for syntax
    details.

``stub-columns`` : integer
    The number of table columns to use as stubs (row titles, on the
    left).  Defaults to 0.

``url`` : string (whitespace removed)
    An Internet URL reference to a CSV data file.

``widths`` : integer [integer...] or "auto"
    A list of relative column widths.
    The default is equal-width columns (100%/#columns).

    "auto" delegates the determination of column widths to the backend
    (LaTeX, the HTML browser, ...).

``width`` : `length`_ or `percentage`_
    Sets the width of the table to the specified length or percentage
    of the line width.  If omitted, the renderer determines the width
    of the table based on its contents or the column ``widths``.

and the common options class_ and name_.

.. [#whitespace-delim] Whitespace delimiters are supported only for external
   CSV files.

.. [#ASCII-char] With PythonÂ 2, the values for the ``delimiter``,
   ``quote``, and ``escape`` options must be ASCII characters. (The csv
   module does not support Unicode and all non-ASCII characters are
   encoded as multi-byte utf-8 string). This limitation does not exist
   under PythonÂ 3.


List Table
==========

:Directive Type: "list-table"
:Doctree Element: table_
:Directive Arguments: One, optional (table title).
:Directive Options: Possible (see below).
:Directive Content: A uniform two-level bullet list.

(This is an initial implementation; `further ideas`__ may be implemented
in the future.)

__ ../../dev/rst/alternatives.html#list-driven-tables

The "list-table" directive is used to create a table from data in a
uniform two-level bullet list.  "Uniform" means that each sublist
(second-level list) must contain the same number of list items.

Example::

    .. list-table:: Frozen Delights!
       :widths: 15 10 30
       :header-rows: 1

       * - Treat
         - Quantity
         - Description
       * - Albatross
         - 2.99
         - On a stick!
       * - Crunchy Frog
         - 1.49
         - If we took the bones out, it wouldn't be
           crunchy, now would it?
       * - Gannet Ripple
         - 1.99
         - On a stick!

The following options are recognized:


``align`` : "left", "center", or "right"
    The horizontal alignment of the table.
    (New in Docutils 0.13)

``header-rows`` : integer
    The number of rows of list data to use in the table header.
    Defaults to 0.

``stub-columns`` : integer
    The number of table columns to use as stubs (row titles, on the
    left).  Defaults to 0.

    .. _table width:

``width`` : `length`_ or `percentage`_
    Sets the width of the table to the specified length or percentage
    of the line width.  If omitted, the renderer determines the width
    of the table based on its contents or the column ``widths``.

    .. _column widths:

``widths`` : integer [integer...] or "auto"
    A list of relative column widths.
    The default is equal-width columns (100%/#columns).

    "auto" delegates the determination of column widths to the backend
    (LaTeX, the HTML browser, ...).

and the common options class_ and name_.


----------------
 Document Parts
----------------

.. _contents:

Table of Contents
=================

:Directive Type: "contents"
:Doctree Elements: pending_, topic_
:Directive Arguments: One, optional: title.
:Directive Options: Possible (see below).
:Directive Content: None.

The "contents" directive generates a table of contents (TOC) in a
topic_.  Topics, and therefore tables of contents, may occur anywhere
a section or transition may occur.  Body elements and topics may not
contain tables of contents.

Here's the directive in its simplest form::

    .. contents::

Language-dependent boilerplate text will be used for the title.  The
English default title text is "Contents".

An explicit title may be specified::

    .. contents:: Table of Contents

The title may span lines, although it is not recommended::

    .. contents:: Here's a very long Table of
       Contents title

Options may be specified for the directive, using a field list::

    .. contents:: Table of Contents
       :depth: 2

If the default title is to be used, the options field list may begin
on the same line as the directive marker::

    .. contents:: :depth: 2

The following options are recognized:

``depth`` : integer
    The number of section levels that are collected in the table of
    contents.  The default is unlimited depth.

``local`` : flag (empty)
    Generate a local table of contents.  Entries will only include
    subsections of the section in which the directive is given.  If no
    explicit title is given, the table of contents will not be titled.

``backlinks`` : "entry" or "top" or "none"
    Generate links from section headers back to the table of contents
    entries, the table of contents itself, or generate no back-links.

``class`` : text
    Set a `"classes"`_ attribute value on the topic element.  See the
    class_ directive below.


.. _sectnum:
.. _section-numbering:

Automatic Section Numbering
===========================

:Directive Type: "sectnum" or "section-numbering" (synonyms)
:Doctree Elements: pending_, generated_
:Directive Arguments: None.
:Directive Options: Possible (see below).
:Directive Content: None.
:Configuration Setting: sectnum_xform_

The "sectnum" (or "section-numbering") directive automatically numbers
sections and subsections in a document (if not disabled by the
``--no-section-numbering`` command line option or the `sectnum_xform`_
configuration setting).

Section numbers are of the "multiple enumeration" form, where each
level has a number, separated by periods.  For example, the title of section
1, subsection 2, subsubsection 3 would have "1.2.3" prefixed.

The "sectnum" directive does its work in two passes: the initial parse
and a transform.  During the initial parse, a "pending" element is
generated which acts as a placeholder, storing any options internally.
At a later stage in the processing, the "pending" element triggers a
transform, which adds section numbers to titles.  Section numbers are
enclosed in a "generated" element, and titles have their "auto"
attribute set to "1".

The following options are recognized:

``depth`` : integer
    The number of section levels that are numbered by this directive.
    The default is unlimited depth.

``prefix`` : string
    An arbitrary string that is prefixed to the automatically
    generated section numbers.  It may be something like "3.2.", which
    will produce "3.2.1", "3.2.2", "3.2.2.1", and so on.  Note that
    any separating punctuation (in the example, a period, ".") must be
    explicitly provided.  The default is no prefix.

``suffix`` : string
    An arbitrary string that is appended to the automatically
    generated section numbers.  The default is no suffix.

``start`` : integer
    The value that will be used for the first section number.
    Combined with ``prefix``, this may be used to force the right
    numbering for a document split over several source files.  The
    default is 1.

.. _sectnum_xform: ../../user/config.html#sectnum-xform


.. _header:
.. _footer:

Document Header & Footer
========================

:Directive Types: "header" and "footer"
:Doctree Elements: decoration_, header, footer
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as body elements.

The "header" and "footer" directives create document decorations,
useful for page navigation, notes, time/datestamp, etc.  For example::

    .. header:: This space for rent.

This will add a paragraph to the document header, which will appear at
the top of the generated web page or at the top of every printed page.

These directives may be used multiple times, cumulatively.  There is
currently support for only one header and footer.

.. note::

   While it is possible to use the "header" and "footer" directives to
   create navigational elements for web pages, you should be aware
   that Docutils is meant to be used for *document* processing, and
   that a navigation bar is not typically part of a document.

   Thus, you may soon find Docutils' abilities to be insufficient for
   these purposes.  At that time, you should consider using a
   documentation generator like Sphinx_ rather than the "header" and
   "footer" directives.

   .. _Sphinx: http://sphinx-doc.org/

In addition to the use of these directives to populate header and
footer content, content may also be added automatically by the
processing system.  For example, if certain runtime settings are
enabled, the document footer is populated with processing information
such as a datestamp, a link to `the Docutils website`_, etc.

.. _the Docutils website: https://docutils.sourceforge.io


------------
 References
------------

.. _target-notes:

Target Footnotes
================

:Directive Type: "target-notes"
:Doctree Elements: pending_, footnote_, footnote_reference_
:Directive Arguments: None.
:Directive Options: class_, name_
:Directive Options: Possible (see below).
:Directive Content: None.

The "target-notes" directive creates a footnote for each external
target in the text, and corresponding footnote references after each
reference.  For every explicit target (of the form, ``.. _target name:
URL``) in the text, a footnote will be generated containing the
visible URL as content.


Footnotes
=========

**NOT IMPLEMENTED YET**

:Directive Type: "footnotes"
:Doctree Elements: pending_, topic_
:Directive Arguments: None?
:Directive Options: Possible?
:Directive Content: None.

@@@


Citations
=========

**NOT IMPLEMENTED YET**

:Directive Type: "citations"
:Doctree Elements: pending_, topic_
:Directive Arguments: None?
:Directive Options: Possible?
:Directive Content: None.

@@@


---------------
 HTML-Specific
---------------

Imagemap
========

**NOT IMPLEMENTED YET**

Non-standard element: imagemap.


-----------------------------------------
 Directives for Substitution Definitions
-----------------------------------------

The directives in this section may only be used in `substitution
definitions`_.  They may not be used directly, in standalone context.
The `image`_ directive may be used both in substitution definitions
and in the standalone context.

.. _substitution definitions:
.. _substitution definition: restructuredtext.html#substitution-definitions

.. _replace:

Replacement Text
================

:Directive Type: "replace"
:Doctree Element: Text & `inline elements`_
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: A single paragraph; may contain inline markup.

The "replace" directive is used to indicate replacement text for a
substitution reference.  It may be used within `substitution
definitions`_ only.  For example, this directive can be used to expand
abbreviations::

    .. |reST| replace:: reStructuredText

    Yes, |reST| is a long word, so I can't blame anyone for wanting to
    abbreviate it.

As reStructuredText doesn't support nested inline markup, the only way
to create a reference with styled text is to use substitutions with
the "replace" directive::

    I recommend you try |Python|_.

    .. |Python| replace:: Python, *the* best language around
    .. _Python: https://www.python.org/


.. _unicode:

Unicode Character Codes
=======================

:Directive Type: "unicode"
:Doctree Element: Text
:Directive Arguments: One or more, required (Unicode character codes,
                      optional text, and comments).
:Directive Options: Possible (see below).
:Directive Content: None.

The "unicode" directive converts Unicode character codes (numerical
values) to characters, and may be used in `substitution definitions`_
only.

The arguments, separated by spaces, can be:

* **character codes** as

  - decimal numbers or

  - hexadecimal numbers, prefixed by ``0x``, ``x``, ``\x``, ``U+``, ``u``, or ``\u`` or as XML-style hexadecimal character entities, e.g. ``&#x1a2b;``

* **text**, which is used as-is.

Text following " .. " is a comment and is ignored.  The spaces between
the arguments are ignored and thus do not appear in the output.
Hexadecimal codes are case-insensitive.

For example, the following text::

    Copyright |copy| 2003, |BogusMegaCorp (TM)| |---|
    all rights reserved.

    .. |copy| unicode:: 0xA9 .. copyright sign
    .. |BogusMegaCorp (TM)| unicode:: BogusMegaCorp U+2122
       .. with trademark sign
    .. |---| unicode:: U+02014 .. em dash
       :trim:

results in:

    Copyright |copy| 2003, |BogusMegaCorp (TM)| |---|
    all rights reserved.

    .. |copy| unicode:: 0xA9 .. copyright sign
    .. |BogusMegaCorp (TM)| unicode:: BogusMegaCorp U+2122
       .. with trademark sign
    .. |---| unicode:: U+02014 .. em dash
       :trim:

The following options are recognized:

``ltrim`` : flag (empty)
    Whitespace to the left of the substitution reference is removed.

``rtrim`` : flag (empty)
    Whitespace to the right of the substitution reference is removed.

``trim`` : flag (empty)
    Equivalent to ``ltrim`` plus ``rtrim``; whitespace on both sides
    of the substitution reference is removed.


Date
====

:Directive Type: "date"
:Doctree Element: Text
:Directive Arguments: One, optional (date format).
:Directive Options: None.
:Directive Content: None.

The "date" directive generates the current local date and inserts it
into the document as text.  This directive may be used in substitution
definitions only.

The optional directive content is interpreted as the desired date
format, using the same codes as Python's `time.strftime()`__ function.  The
default format is "%Y-%m-%d" (ISO 8601 date), but time fields can also
be used.  Examples::

    .. |date| date::
    .. |time| date:: %H:%M

    Today's date is |date|.

    This document was generated on |date| at |time|.

__ https://docs.python.org/3/library/time.html#time.strftime


---------------
 Miscellaneous
---------------

.. _include:

Including an External Document Fragment
=======================================

:Directive Type: "include"
:Doctree Elements: Depend on data being included
                   (literal_block_ with ``code`` or ``literal`` option).
:Directive Arguments: One, required (path to the file to include).
:Directive Options: Possible (see below).
:Directive Content: None.
:Configuration Setting: file_insertion_enabled_

.. WARNING::

   The "include" directive represents a potential security hole.  It
   can be disabled with the "file_insertion_enabled_" runtime setting.

   .. _file_insertion_enabled: ../../user/config.html#file-insertion-enabled

The "include" directive reads a text file. The directive argument is
the path to the file to be included, relative to the document containing
the directive. Unless the options ``literal``, ``code``, or ``parser``
are given, the file is parsed in the current document's context at the
point of the directive. For example::

    This first example will be parsed at the document level, and can
    thus contain any construct, including section headers.

    .. include:: inclusion.txt

    Back in the main document.

        This second example will be parsed in a block quote context.
        Therefore it may only contain body elements.  It may not
        contain section headers.

        .. include:: inclusion.txt

If an included document fragment contains section structure, the title
adornments must match those of the master document.

Standard data files intended for inclusion in reStructuredText
documents are distributed with the Docutils source code, located in
the "docutils" package in the ``docutils/parsers/rst/include``
directory.  To access these files, use the special syntax for standard
"include" data files, angle brackets around the file name::

    .. include:: <isonum.txt>

The current set of standard "include" data files consists of sets of
substitution definitions.  See `reStructuredText Standard Definition
Files`__ for details.

__ definitions.html

The following options are recognized:

``start-line`` : integer
    Only the content starting from this line will be included.
    (As usual in Python, the first line has index 0 and negative values
    count from the end.)

``end-line`` : integer
    Only the content up to (but excluding) this line will be included.

``start-after`` : text to find in the external data file
    Only the content after the first occurrence of the specified text
    will be included.

``end-before`` : text to find in the external data file
    Only the content before the first occurrence of the specified text
    (but after any ``after`` text) will be included.

``parser`` :  parser name
    Parse the included content with the specified parser.
    (New in Docutils 0.17)

``literal`` : flag (empty)
    The entire included text is inserted into the document as a single
    literal block.

``code`` : [string] (formal language)
    The argument and the included content are passed to
    the code_ directive (useful for program listings).

``number-lines`` : [integer] (start line number)
    Precede every code line with a line number.
    The optional argument is the number of the first line (default 1).
    Works only with ``code`` or ``literal``.

``encoding`` : string
    The text encoding of the external data file.  Defaults to the
    document's input_encoding_.

    .. _input_encoding: ../../user/config.html#input-encoding

``tab-width`` :  integer
    Number of spaces for hard tab expansion.
    A negative value prevents expansion of hard tabs. Defaults to the
    tab_width_ configuration setting.

    .. _tab_width: ../../user/config.html#tab-width

With ``code`` or ``literal`` the common options class_ and
name_ are recognized as well.

Combining ``start/end-line`` and ``start-after/end-before`` is possible. The
text markers will be searched in the specified lines (further limiting the
included content).

.. _raw-directive:

Raw Data Pass-Through
=====================

:Directive Type: "raw"
:Doctree Element: raw_
:Directive Arguments: One or more, required (output format types).
:Directive Options: Possible (see below).
:Directive Content: Stored verbatim, uninterpreted.  None (empty) if a
                    "file" or "url" option given.
:Configuration Setting: raw_enabled_

.. WARNING::

   The "raw" directive represents a potential security hole.  It can
   be disabled with the "raw_enabled_" or "file_insertion_enabled_"
   runtime settings.

   .. _raw_enabled: ../../user/config.html#raw-enabled

.. Caution::

   The "raw" directive is a stop-gap measure allowing the author to
   bypass reStructuredText's markup.  It is a "power-user" feature
   that should not be overused or abused.  The use of "raw" ties
   documents to specific output formats and makes them less portable.

   If you often need to use the "raw" directive or a "raw"-derived
   interpreted text role, that is a sign either of overuse/abuse or
   that functionality may be missing from reStructuredText.  Please
   describe your situation in a message to the Docutils-users_ mailing
   list.

.. _Docutils-users: ../../user/mailing-lists.html#docutils-users

The "raw" directive indicates non-reStructuredText data that is to be
passed untouched to the Writer.  The names of the output formats are
given in the directive arguments.  The interpretation of the raw data
is up to the Writer.  A Writer may ignore any raw output not matching
its format.

For example, the following input would be passed untouched by an HTML
Writer::

    .. raw:: html

       <hr width=50 size=10>

A LaTeX Writer could insert the following raw content into its
output stream::

    .. raw:: latex

       \setlength{\parindent}{0pt}

Raw data can also be read from an external file, specified in a
directive option.  In this case, the content block must be empty.  For
example::

    .. raw:: html
       :file: inclusion.html

Inline equivalents of the "raw" directive can be defined via
`custom interpreted text roles`_ derived from the `"raw" role`_.

The following options are recognized:

``file`` : string (newlines removed)
    The local filesystem path of a raw data file to be included.

``url`` : string (whitespace removed)
    An Internet URL reference to a raw data file to be included.

``encoding`` : string
    The text encoding of the external raw data (file or URL).
    Defaults to the document's encoding (if specified).

and the common option class_.


.. _"raw" role: roles.html#raw


.. _classes:

Class
=====

:Directive Type: "class"
:Doctree Element: pending_
:Directive Arguments: One or more, required (class names / attribute
                      values).
:Directive Options: None.
:Directive Content: Optional.  If present, it is interpreted as body
                    elements.

The "class" directive sets the `"classes"`_ attribute value on its content
or on the first immediately following [#]_ non-comment element [#]_.
The directive argument consists of one or more space-separated class
names. The names are transformed to conform to the regular expression
``[a-z](-?[a-z0-9]+)*`` (see `Identifier Normalization`_ below).

Examples::

    .. class:: special

    This is a "special" paragraph.

    .. class:: exceptional remarkable

    An Exceptional Section
    ======================

    This is an ordinary paragraph.

    .. class:: multiple

       First paragraph.

       Second paragraph.

The text above is parsed and transformed into this doctree fragment::

.. code-block:: xml

    <paragraph classes="special">
        This is a "special" paragraph.
    <section classes="exceptional remarkable">
        <title>
            An Exceptional Section
        <paragraph>
            This is an ordinary paragraph.
        <paragraph classes="multiple">
            First paragraph.
        <paragraph classes="multiple">
            Second paragraph.


.. [#] This is also true, if the class directive is "nested" at the end of
   an indented text block, for example::

       .. note:: the class values set in this directive-block do not apply to
          the note but the next paragraph.

          .. class:: special

       This is a paragraph with class value "special".

   This allows the "classification" of individual list items (except the
   first, as a preceding class directive applies to the list as a whole)::

       * bullet list

         .. class:: classy item

       * second item, with class argument

.. [#] To set a "classes" attribute value on a block quote, the
   "class" directive must be followed by an empty comment::

       .. class:: highlights
       ..

           Block quote text.

   Without the empty comment, the indented text would be interpreted as the
   "class" directive's content, and the classes would be applied to each
   element (paragraph, in this case) individually, instead of to the block
   quote as a whole.


Identifier Normalization
~~~~~~~~~~~~~~~~~~~~~~~~

Docutils `class names`_ and `identifier keys`_ are normalized to conform
to the regular expression "``[a-z](-?[a-z0-9]+)*``" by converting

* alphabetic characters to lowercase,
* accented characters to the base character,
* non-alphanumeric characters to hyphens,
* consecutive hyphens into one hyphen

and stripping

* leading hyphens and number characters, and
* trailing hyphens.

For example ``"Rot.Gelb&GrÃ¼n:+2008"`` becomes ``"rot-gelb-grun-2008"`` and
``"1000_Steps!"`` becomes ``"steps"``.

.. topic:: Rationale:

    Identifier keys must be valid in all supported output formats.

    For HTMLÂ 4.1 + CSS1 compatibility, identifiers should have no
    underscores, colons, or periods.  Hyphens may be used.

    - The `HTML 4.01 spec`_ defines identifiers based on SGML tokens:

          ID and NAME tokens must begin with a letter ([A-Za-z]) and
          may be followed by any number of letters, digits ([0-9]),
          hyphens ("-"), underscores ("_"), colons (":"), and periods
          (".").

          -- https://www.w3.org/TR/html401/types.html#type-name

    - The `CSS1 spec`_ defines identifiers based on the "name" token
      ("flex" tokenizer notation below; "latin1" and "escape" 8-bit
      characters have been replaced with XML entities)::

          unicode     \\[0-9a-f]{1,4}
          latin1      [&iexcl;-&yuml;]
          escape      {unicode}|\\[ -~&iexcl;-&yuml;]
          nmchar      [-A-Za-z0-9]|{latin1}|{escape}
          name        {nmchar}+

    The CSS1 rule requires underscores ("_"), colons (":"), and
    periods (".") to be escaped [#]_,
    therefore `"classes"`_ and `"ids"`_ attributes should not
    contain these characters.  Combined with HTML4.1 requirements (the
    first character must be a letter; no "unicode", "latin1", or
    "escape" characters), this results in the regular expression
    ``[A-Za-z][-A-Za-z0-9]*``. Docutils adds a normalization by
    downcasing and merge of consecutive hyphens.

    .. [#] CSS identifiers may use underscores ("_") directly in
       `CSSÂ LevelÂ 1`__, `CSS2.1`__, CSS2.2__, and CSS3__.

       __ https://www.w3.org/TR/CSS21/syndata.html#value-def-identifier
       __ https://www.w3.org/TR/CSS/#css-level-1
       __ https://www.w3.org/TR/CSS22/syndata.html
       __ https://www.w3.org/TR/css-syntax-3/#typedef-ident-token

    .. _HTML 4.01 spec: https://www.w3.org/TR/html401/
    .. _CSS1 spec: https://www.w3.org/TR/REC-CSS1

.. _role:

Custom Interpreted Text Roles
=============================

:Directive Type: "role"
:Doctree Element: None; affects subsequent parsing.
:Directive Arguments: Two; one required (new `role name`_), one optional
                      (base role name, in parentheses).
:Directive Options: Possible (depends on base role).
:Directive Content: depends on base role.

The "role" directive dynamically creates a custom `interpreted text
role`_ and registers it with the parser.  This means that after
declaring a role like this::

    .. role:: custom

the document may use the new "custom" role::

    An example of using :custom:`interpreted text`

This will be parsed into the following document tree fragment::

.. code-block:: xml

    <paragraph>
        An example of using
        <inline classes="custom">
            interpreted text

The role must be declared in a document before it can be used.

.. _role name:

Role names are case insensitive and must conform to the rules of
simple `reference names`_ (but do not share a namespace with
hyperlinks, footnotes, and citations).

The new role may be based on an existing role, specified as a second
argument in parentheses (whitespace optional)::

    .. role:: custom(emphasis)

    :custom:`text`

The parsed result is as follows::

.. code-block:: xml

    <paragraph>
        <emphasis classes="custom">
            text

A special case is the `"raw" role`_: derived roles enable
inline `raw data pass-through`_, e.g.::

   .. role:: raw-role(raw)
      :format: html latex

   :raw-role:`raw text`

If no base role is explicitly specified, a generic custom role is
automatically used.  Subsequent interpreted text will produce an
"inline" element with a `"classes"`_ attribute, as in the first example
above.

With most roles, the ":class:" option can be used to set a "classes"
attribute that is different from the role name.  For example::

    .. role:: custom
       :class: special

    :custom:`interpreted text`

This is the parsed result::

.. code-block:: xml

    <paragraph>
        <inline classes="special">
            interpreted text

.. _role class:

The following option is recognized by the "role" directive for most
base roles:

``class`` : text
    Set the `"classes"`_ attribute value on the element produced
    (``inline``, or element associated with a base class) when the
    custom interpreted text role is used.  If no directive options are
    specified, a "class" option with the directive argument (role
    name) as the value is implied.  See the class_ directive above.

Specific base roles may support other options and/or directive
content.  See the `reStructuredText Interpreted Text Roles`_ document
for details.

.. _reStructuredText Interpreted Text Roles: roles.html


.. _default-role:

Setting the Default Interpreted Text Role
=========================================

:Directive Type: "default-role"
:Doctree Element: None; affects subsequent parsing.
:Directive Arguments: One, optional (new default role name).
:Directive Options: None.
:Directive Content: None.

The "default-role" directive sets the default interpreted text role,
the role that is used for interpreted text without an explicit role.
For example, after setting the default role like this::

    .. default-role:: subscript

any subsequent use of implicit-role interpreted text in the document
will use the "subscript" role::

    An example of a `default` role.

This will be parsed into the following document tree fragment

.. code-block:: xml

    <paragraph>
        An example of a
        <subscript>
            default
         role.

Custom roles may be used (see the "role_" directive above), but it
must have been declared in a document before it can be set as the
default role.  See the `reStructuredText Interpreted Text Roles`_
document for details of built-in roles.

The directive may be used without an argument to restore the initial
default interpreted text role, which is application-dependent.  The
initial default interpreted text role of the standard reStructuredText
parser is "title-reference".


Metadata
========

:Directive Type: "meta"
:Doctree Element: meta_
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Must contain a flat field list.

The "meta" directive is used to specify metadata\ [#]_ to be stored
in, e.g., `HTML meta elements`_ or as `ODT file properties`_. The
LaTeX writer passes it to the ``pdfinfo`` option of the hyperref_
package. If an output format does not support "invisible" metadata,
content is silently dropped by the writer.

.. note:: Data from some `bibliographic fields`_ is automatically
   extracted and stored as metadata, too. However, Bibliographic
   Fields are also displayed in the document's screen rendering or
   printout.

   For an "invisible" *document title*, see the `metadata document
   title`_ directive below.

Within the directive block, a flat field list provides the syntax for
metadata.  The field name becomes the contents of the "name" attribute
of the META tag, and the field body (interpreted as a single string
without inline markup) becomes the contents of the "content"
attribute.  For example::

    .. meta::
       :description: The reStructuredText plaintext markup language
       :keywords: plaintext, markup language

This would be converted to the following HTML

.. code-block:: html

    <meta name="description"
        content="The reStructuredText plaintext markup language">
    <meta name="keywords" content="plaintext, markup language">

Support for other META attributes ("http-equiv", "scheme", "lang",
"dir") are provided through field arguments, which must be of the form
"attr=value"::

    .. meta::
       :description lang=en: An amusing story
       :description lang=fr: Une histoire amusante

And their HTML equivalents

.. code-block:: html

    <meta name="description" lang="en" content="An amusing story">
    <meta name="description" lang="fr" content="Une histoire amusante">

Some META tags use an "http-equiv" attribute instead of the "name"
attribute.  To specify "http-equiv" META tags, simply omit the name::

    .. meta::
       :http-equiv=Content-Type: text/html; charset=ISO-8859-1

HTML equivalent

.. code-block:: html

    <meta http-equiv="Content-Type"
         content="text/html; charset=ISO-8859-1">

.. [#] "Metadata" is data about data, in this case data about the
   document. Metadata is, e.g., used to describe and classify web
   pages in the World Wide Web, in a form that is easy for search
   engines to extract and collate.

.. _HTML meta elements:
   https://html.spec.whatwg.org/multipage/semantics.html#the-meta-element
.. _ODT file properties:
   https://en.wikipedia.org/wiki/OpenDocument_technical_specification#Metadata
.. _hyperref: https://ctan.org/pkg/hyperref
.. _bibliographic fields: restructuredtext.html#bibliographic-fields


Metadata Document Title
=======================

:Directive Type: "title"
:Doctree Element: Sets the document's `title attribute`_.
:Directive Arguments: One, required (the title text).
:Directive Options: None.
:Directive Content: None.

The "title" directive specifies the document title as metadata, which
does not become part of the document body. It overrides the
document-supplied `document title`_ and the `"title" configuration
setting`_. For example, in HTML output the metadata document title
appears in the title bar of the browser window.

.. _document title: restructuredtext.html#document-title
.. _"title" configuration setting: ../../user/config.html#title

Restructuredtext-Test-Directive
===============================

:Directive Type: "restructuredtext-test-directive"
:Doctree Element: system_warning
:Directive Arguments: None.
:Directive Options: None.
:Directive Content: Interpreted as a literal block.

This directive is provided for test purposes only.  (Nobody is
expected to type in a name *that* long!)  It is converted into a
level-1 (info) system message showing the directive data, possibly
followed by a literal block containing the rest of the directive
block.

--------------
Common Options
--------------

Most of the directives that generate doctree elements support the following
options:

.. _class-option:
.. _class:

``class`` : text (space separated list of `class names`_)
    Set a `"classes"`_ attribute value on the doctree element generated by
    the directive. See also the class_ directive.

    .. _name:

``name`` : text
    Add `text` to the `"names"`_ attribute of the doctree element generated
    by the directive. This allows `hyperlink references`_ to the element
    using `text` as `reference name`_.

    Specifying the `name` option of a directive, e.g., ::

      .. image:: bild.png
         :name: my picture

    is a concise syntax alternative to preceding it with a `hyperlink
    target`_ ::

      .. _my picture:

      .. image:: bild.png


.. _reference name:
.. _reference names: restructuredtext.html#reference-names
.. _hyperlink target: restructuredtext.html#hyperlink-targets
.. _hyperlink references: restructuredtext.html#hyperlink-references
.. _class names: ../doctree.html#classnames-type
.. _"classes": ../doctree.html#classes
.. _identifier keys: ../doctree.html#ids-type
.. _"ids": ../doctree.html#ids
.. _"names": ../doctree.html#names
.. _admonition: ../doctree.html#admonition
.. _block_quote: ../doctree.html#block-quote
.. _caption: ../doctree.html#caption
.. _compound: ../doctree.html#compound
.. _container element: ../doctree.html#container
.. _decoration: ../doctree.html#decoration
.. _figure: ../doctree.html#figure
.. _footnote: ../doctree.html#footnote
.. _footnote_reference: ../doctree.html#footnote-reference
.. _generated: ../doctree.html#generated
.. _image: ../doctree.html#image
.. _inline elements: ../doctree.html#inline-elements
.. _interpreted text role: roles.html
.. _literal_block: ../doctree.html#literal-block
.. _legend: ../doctree.html#legend
.. _length: restructuredtext.html#length-units
.. _line_block: ../doctree.html#line-block
.. _math_block: ../doctree.html#math-block
.. _meta: ../doctree.html#meta
.. _pending: ../doctree.html#pending
.. _percentage: restructuredtext.html#percentage-units
.. _raw: ../doctree.html#raw
.. _rubric: ../doctree.html#rubric
.. _sidebar: ../doctree.html#sidebar
.. _table: ../doctree.html#table
.. _title: ../doctree.html#title
.. _title attribute: ../doctree.html#title-attribute
.. _topic: ../doctree.html#topic



..
   Local Variables:
   mode: indented-text
   indent-tabs-mode: nil
   sentence-end-double-space: t
   fill-column: 70
   End:
