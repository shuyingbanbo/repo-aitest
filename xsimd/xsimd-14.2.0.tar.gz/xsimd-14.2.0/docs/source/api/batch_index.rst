.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay 

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

.. _Batch Types:

Batch Types
===========

.. toctree::
   :maxdepth: 1

   xsimd_batch
   xsimd_batch_bool
   xsimd_batch_complex
   xsimd_batch_constant
