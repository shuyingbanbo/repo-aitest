// Copyright (c) 2017-2026, University of Cincinnati, developed by Henry Schreiner
// under NSF AWARD 1414736 and by the respective contributors.
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause

#pragma once

// IWYU pragma: private, include "CLI/CLI.hpp"

// [CLI11:version_hpp:verbatim]

#define CLI11_VERSION_MAJOR 2
#define CLI11_VERSION_MINOR 6
#define CLI11_VERSION_PATCH 2
#define CLI11_VERSION "2.6.2"

// [CLI11:version_hpp:end]
