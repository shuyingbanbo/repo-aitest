echo "Running mypy..."
mypy fast_depends

echo "Running ruff linter (isort, flake, pyupgrade, etc. replacement)..."
ruff check fast_depends tests --fix

echo "Running ruff formatter (black replacement)..."
ruff format fast_depends tests

echo "Running codespell to find typos..."
codespell
