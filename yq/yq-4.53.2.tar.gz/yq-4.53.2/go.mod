module github.com/mikefarah/yq/v4

require (
	github.com/a8m/envsubst v1.4.3
	github.com/alecthomas/participle/v2 v2.1.4
	github.com/alecthomas/repr v0.5.2
	github.com/dimchansky/utfbom v1.1.1
	github.com/elliotchance/orderedmap v1.8.0
	github.com/fatih/color v1.19.0
	github.com/go-ini/ini v1.67.0
	github.com/goccy/go-json v0.10.6
	github.com/goccy/go-yaml v1.19.2
	github.com/hashicorp/hcl/v2 v2.24.0
	github.com/jinzhu/copier v0.4.0
	github.com/magiconair/properties v1.8.10
	github.com/pelletier/go-toml/v2 v2.3.0
	github.com/pkg/diff v0.0.0-20210226163009-20ebb0f2a09e
	github.com/spf13/cobra v1.10.2
	github.com/spf13/pflag v1.0.10
	github.com/yuin/gopher-lua v1.1.2
	github.com/zclconf/go-cty v1.18.1
	go.yaml.in/yaml/v4 v4.0.0-rc.4
	golang.org/x/mod v0.34.0
	golang.org/x/net v0.53.0
	golang.org/x/text v0.36.0
)

require (
	github.com/agext/levenshtein v1.2.1 // indirect
	github.com/apparentlymart/go-textseg/v15 v15.0.0 // indirect
	github.com/google/go-cmp v0.6.0 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mitchellh/go-wordwrap v1.0.1 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
	golang.org/x/tools v0.43.0 // indirect
)

go 1.25.0
