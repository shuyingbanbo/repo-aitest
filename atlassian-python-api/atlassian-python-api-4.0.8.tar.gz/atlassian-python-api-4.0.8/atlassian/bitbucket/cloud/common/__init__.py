"""Bitbucket Cloud common package"""
