package org.jsoup.integration;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.integration.routes.RedirectRoute;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import static org.jsoup.helper.AuthenticationHandlerTest.MaxAttempts;
import static org.jsoup.integration.ConnectTest.ihVal;
import static org.jsoup.integration.TestServer.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 Tests Jsoup.connect proxy support
 */
public class ProxyTest {
    private static String echoUrl;
    private static ProxySettings proxy;

    @BeforeAll
    public static void setUp() {
        echoUrl = origin().echo.url();
        proxy = proxySettings();
    }

    @ParameterizedTest
    @MethodSource("helloUrls")
    void fetchViaProxy(String url) throws IOException {
        Connection con = Jsoup.connect(url)
            .proxy(proxy.hostname, proxy.port);

        Connection.Response res = con.execute();
        if (url.startsWith("http:/")) assertVia(res); // HTTPS CONNECT won't have Via

        Document doc = res.parse();
        Element p = doc.expectFirst("p");
        assertEquals("Hello, World!", p.text());
    }

    private static Stream<String> helloUrls() {
        return Stream.of(origin().hello.url(), origin().hello.tlsUrl());
    }

    private static Stream<String> echoUrls() {
        return Stream.of(origin().echo.url(), origin().echo.tlsUrl());
    }

    private static void assertVia(Connection.Response res) {
        assertEquals(res.header("Via"), ProxyVia);
    }

    @Test
    void redirectViaProxy() throws IOException {
        Connection.Response res = Jsoup
            .connect(origin().redirect.url())
            .data(RedirectRoute.LocationParam, echoUrl)
            .header("Random-Header-name", "hello")
            .proxy(proxy.hostname, proxy.port)
            .execute();

        assertVia(res);
        Document doc = res.parse();
        assertEquals(echoUrl, doc.location());
        assertEquals("hello", ihVal("Random-Header-name", doc));
        assertVia(res);
    }

    @Test
    void proxyForSession() throws IOException {
        Connection session = Jsoup.newSession().proxy(proxy.hostname, proxy.port);

        Connection.Response medRes = session.newRequest(origin().file.url("/htmltests/medium.html")).execute();
        Connection.Response largeRes = session.newRequest(origin().file.url("/htmltests/large.html")).execute();

        assertVia(medRes);
        assertVia(largeRes);
        assertEquals("Medium HTML", medRes.parse().title());
        assertEquals("Large HTML", largeRes.parse().title());

        Connection.Response smedRes = session.newRequest(origin().file.tlsUrl("/htmltests/medium.html")).execute();
        Connection.Response slargeRes = session.newRequest(origin().file.tlsUrl("/htmltests/large.html")).execute();

        assertEquals("Medium HTML", smedRes.parse().title());
        assertEquals("Large HTML", slargeRes.parse().title());
    }

    @ParameterizedTest
    @MethodSource("echoUrls")
    void canAuthenticateToProxy(String url) throws IOException {
        int closed =
            closeAuthedProxyConnections(); // reset any existing authed connections from previous tests, so we can test the auth flow

        // the proxy wants auth, but not the server. HTTP and HTTPS, so tests direct proxy and CONNECT
        Connection session = Jsoup.newSession()
            .proxy(proxy.hostname, proxy.authedPort)
            .ignoreHttpErrors(true)
            .ignoreContentType(true); // ignore content type, as error served may not have a content type
        String password = TestAuth.newProxyPassword();

        // fail first
        try {
            Connection.Response execute = session.newRequest(url)
                .execute();
            int code = execute.statusCode(); // no auth sent
            assertEquals(TestAuth.failureStatus(true), code);
        } catch (IOException e) {
            assertAuthRequiredException(e);
        }

        try {
            AtomicInteger count = new AtomicInteger(0);
            Connection.Response res = session.newRequest(url)
                .auth(ctx -> {
                    count.incrementAndGet();
                    return ctx.credentials(TestAuth.ProxyUser, password + "wrong"); // incorrect
                })
                .execute();
            assertEquals(MaxAttempts, count.get());
            assertEquals(TestAuth.failureStatus(true), res.statusCode());
        } catch (IOException e) {
            assertAuthRequiredException(e);
        }

        AtomicInteger successCount = new AtomicInteger(0);
        Connection.Response successRes = session.newRequest(url)
            .auth(ctx -> {
                successCount.incrementAndGet();
                return ctx.credentials(TestAuth.ProxyUser, password); // correct
            })
            .execute();
        assertEquals(1, successCount.get());
        assertEquals(200, successRes.statusCode());
    }

    static void assertAuthRequiredException(IOException e) {
        // in CONNECT (for the HTTPS url), URLConnection will throw the proxy connect as a Stringly typed IO exception - "Unable to tunnel through proxy. Proxy returns "HTTP/1.1 407 Proxy Authentication Required"". (Not a response code)
        // Alternatively, some platforms (?) will report: "No credentials provided"
        String err = e.getMessage();
        if (!(err.contains("407") || err.contains("No credentials provided") || err.contains("exch.exchImpl"))) {
            // https://github.com/jhy/jsoup/pull/2403 - Ubuntu Azul 25 throws `Cannot invoke "jdk.internal.net.http.ExchangeImpl.cancel(java.io.IOException)" because "exch.exchImpl" is null` here but is just from cancelling the 407 req
            System.err.println("Not a 407 exception? " + e.getClass());
            e.printStackTrace(System.err);
            fail("Expected 407 Proxy Authentication Required, got: " + err);
        }
    }

    @ParameterizedTest
    @MethodSource("echoUrls")
    void canAuthToProxyAndServer(String url) throws IOException {
        String serverPassword = TestAuth.newServerPassword();
        String proxyPassword = TestAuth.newProxyPassword();
        AtomicInteger count = new AtomicInteger(0);

        Connection session = Jsoup.newSession() // both proxy and server will want auth
            .proxy(proxy.hostname, proxy.authedPort)
            .header(TestAuth.WantsServerAuthentication, "1")
            .auth(auth -> {
                count.incrementAndGet();

                if (auth.isServer()) {
                    assertEquals(url, auth.url().toString());
                    assertEquals(TestAuth.ServerRealm, auth.realm());
                    return auth.credentials(TestAuth.ServerUser, serverPassword);
                } else {
                    assertTrue(auth.isProxy());
                    return auth.credentials(TestAuth.ProxyUser, proxyPassword);
                }
            });


        Connection.Response res = session.newRequest(url).execute();
        assertEquals(200, res.statusCode());
        assertEquals(2, count.get()); // hit server and proxy auth stages
        assertEquals("Webserver Environment Variables", res.parse().title());
    }
}
