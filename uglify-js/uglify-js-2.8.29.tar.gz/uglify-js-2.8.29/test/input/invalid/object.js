console.log({%: 1});
